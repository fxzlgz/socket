from test import*
import time 
t=time.time()

for i in range(10):
    #count(1,1)
    io()
print(time.time()-t)