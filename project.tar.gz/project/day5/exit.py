import os,sys

#os._exit(0)
sys.exit()
print("Process over")
